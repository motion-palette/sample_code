# Keep this file separate

# https://apps.twitter.com/
# Create new App

def oauth():
    return {"consumer_key": "",
            "consumer_secret": "",
            "token_key": "",
            "token_secret": ""}